package com.GelatoPro3.Enum;

public enum Type
{
	AUTRE_AROME,
	SUCRE,
	CHOCOLAT,
	STABILISANT,
	FRUIT_SUCRE,
	FRUIT100
}
