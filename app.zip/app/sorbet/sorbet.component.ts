import { AfterViewInit, Component } from '@angular/core';
import {Ingredient} from '../model/ingredient.model'
import {TypeGlace} from '../model/typeGlace.model'
import {TypeGras} from '../model/typeGras.model'
import {TypeArome} from '../model/typeArome.model'
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-sorbet',
  templateUrl: './sorbet.component.html',
  styleUrls: ['./sorbet.component.scss']
})


@Injectable()
export class SorbetComponent {

  ngAfterContentInit()
   {
    this.getAllTypeGlace();
    this.getAllTypeGras();
    this.getAllTypeArome();
    this.getAllFruit100();
    this.getAllFruitSucre();
    this.getAllChocolat();
    this.getAllAutreArome();
    this.getSaccharoseIngredient();
    this.getSucreInvertiIngredient();
    this.getDextroseIngredient();
    this.getStabilisant();
  }
  
  constructor(private http: HttpClient) { }

  apiServerUrl='http://localhost:8080'

  debug : boolean = false;
  aide : boolean = true;
  ajouterMG: boolean=false;
  selectedTypeGlace = '';
  poudreLaitSorbet : boolean = false;
  selectedTypeGras1 = '';
  selectedTypeGras2 = '';
  poidsTotalMIX : number = 10000;
  stabilisantPourCent : number = 0;
  grasTotalPourCent : number = 8;
  esdlTotalPourCent : number = 9.5;
  prixTotal : number = 0;
  pouvoirSucrantTotal : number = 0;
  poidsSucreArometotal : number = 0;
  sucreAjoute : number = 0;
  poidsEau: number = 0;
  extraitSecTotal: number = 0;
  tauxFruit: number = 0;
  poidsGras1: number = 0;
  poidsGras2: number = 0;
  poidsPoudreLait : number = 0;
  poidsLaitEntier : number = 0;
  jauneDoeufPourCent : number = 0;
  poudreLaitSorbetPourcent : number = 0;
  
  stabilisant = {} as Ingredient;
  sucreTotalPourCent : number = 20;
  saccharose = {} as Ingredient;
  glucose  = {} as Ingredient;
  sucreInverti  = {} as Ingredient;
  dextrose  = {} as Ingredient;

  saccharosePourCent : number  = 100;
  glucosePourCent : number   = 0;
  sucreInvertiPourCent : number   = 0;
  dextrosePourCent : number   = 0;

  allTypeGras: TypeGras[] = [];
  allTypeGlace: TypeGlace[] = [];
  allTypeArome: TypeArome[] = [];
  allChocolat: Ingredient[] = [];
  allFruitSucre: Ingredient[] = [];
  allFruit100: Ingredient[] = [];
  allAutreArome: Ingredient[] = [];
  allArome1: Ingredient[] = [];
  allArome2: Ingredient[] = [];
  allArome3: Ingredient[] = [];
  allArome4: Ingredient[] = [];
  
  nomArome1 = '';
  nomArome2 = '';
  nomArome3 = '';
  nomArome4 = '';

  arome1 = {} as Ingredient;
  arome2 = {} as Ingredient;
  arome3 = {} as Ingredient;
  arome4 = {} as Ingredient;

  selectedTypeArome1 = '';
  selectedTypeArome2 = '';
  selectedTypeArome3 = '';
  selectedTypeArome4 = '';

  pourCentArome1 : number = 0;
  pourCentArome2 : number = 0;
  pourCentArome3 : number = 0;
  pourCentArome4 : number = 0;
  

  fournisseurArome1 = '';
  fournisseurArome2 = '';
  fournisseurArome3 = '';
  fournisseurArome4 = '';

   typeAromeMap = { 
   Chocolat: 'chocolat',
   Fruit_s: 'fruit_ s',
   Fruit100: 'fruit 100',
   Autrearome: 'autre',
  };


  allIngredient: Ingredient[] = []; 
  typeAromeListFake1: TypeArome[] = [];

getSaccharoseIngredient() : void {
  
   this.http.get<Ingredient>((`${this.apiServerUrl}/api/ingredient/saccharose`)).
   subscribe(
    x => {
      console.log('Observer got a next value: ' + x);
      this.saccharose=x;
    } ,
    err => console.error('Observer got an error: ' + err),
    () => console.log('Observer got a complete notification')
  );
}

getGlucoseIngredient() : void {
  
  this.http.get<Ingredient>((`${this.apiServerUrl}/api/ingredient/glucose`)).
  subscribe(
   x => {
     console.log('Observer got a next value: ' + x);
     this.glucose=x;
   } ,
   err => console.error('Observer got an error: ' + err),
   () => console.log('Observer got a complete notification')
 );
}

getSucreInvertiIngredient() : void {
  
  this.http.get<Ingredient>((`${this.apiServerUrl}/api/ingredient/sucre-inverti`)).
  subscribe(
   x => {
     console.log('Observer got a next value: ' + x);
     this.sucreInverti=x;
   } ,
   err => console.error('Observer got an error: ' + err),
   () => console.log('Observer got a complete notification')
 );
}

getDextroseIngredient() : void {
  
  this.http.get<Ingredient>((`${this.apiServerUrl}/api/ingredient/dextrose`)).
  subscribe(
   x => {
     console.log('Observer got a next value: ' + x);
     this.dextrose=x;
   } ,
   err => console.error('Observer got an error: ' + err),
   () => console.log('Observer got a complete notification')
 );
}

getAllChocolat() : void {
  this.http.get<Ingredient[]>((`${this.apiServerUrl}/api/ingredient/chocolat/all`)).
  subscribe(
   x => {
     console.log('Observer got a next value: ' + x);
     x.forEach(element => {
       console.log(element.nom);
     });
     this.allChocolat=x;
   } ,
   err => console.error('Observer got an error: ' + err),
   () => console.log('Observer got a complete notification')
 );
}

getAllFruit100() : void {
  this.http.get<Ingredient[]>((`${this.apiServerUrl}/api/ingredient/fruit100/all`)).
  subscribe(
   x => {
     console.log('Observer got a next value: ' + x);
     x.forEach(element => {
       console.log(element.nom);
     });
     this.allFruit100=x;
   } ,
   err => console.error('Observer got an error: ' + err),
   () => console.log('Observer got a complete notification')
 );
}

getAllFruitSucre() : void {
  this.http.get<Ingredient[]>((`${this.apiServerUrl}/api/ingredient/fruit-sucre/all`)).
  subscribe(
   x => {
     console.log('Observer got a next value: ' + x);
     x.forEach(element => {
       console.log(element.nom);
     });
     this.allFruitSucre=x;
   } ,
   err => console.error('Observer got an error: ' + err),
   () => console.log('Observer got a complete notification')
 );
}

getAllAutreArome() : void {
  this.http.get<Ingredient[]>((`${this.apiServerUrl}/api/ingredient/autre-arome/all`)).
  subscribe(
   x => {
     console.log('Observer got a next value: ' + x);
     x.forEach(element => {
       console.log(element.nom);
     });
     this.allAutreArome=x;
   } ,
   err => console.error('Observer got an error: ' + err),
   () => console.log('Observer got a complete notification')
 );
}

getAllTypeGras() : void {
  this.http.get<TypeGras[]>((`${this.apiServerUrl}/api/ingredient/type-gras/all`)).
  subscribe(
   x => {
     console.log('Observer got a next value: ' + x);
     x.forEach(element => {
       console.log(element.libelle);
     });
     this.allTypeGras=x;
   } ,
   err => console.error('Observer got an error: ' + err),
   () => console.log('Observer got a complete notification')
 );
  }

getAllTypeGlace() : void {
  this.http.get<TypeGlace[]>((`${this.apiServerUrl}/api/ingredient/type-glace/all`)).
  subscribe(
   x => {
     console.log('Observer got a next value: ' + x);
     x.forEach(element => {
       console.log(element.libelle);
     });
     this.allTypeGlace=x;
   } ,
   err => console.error('Observer got an error: ' + err),
   () => console.log('Observer got a complete notification')
 );
}

getAllTypeArome() : void {
  this.http.get<TypeArome[]>((`${this.apiServerUrl}/api/ingredient/type-arome/all`)).
  subscribe(
   x => {
     console.log('Observer got a next value: ' + x);
     x.forEach(element => {
       console.log(element.libelle);
     });
     this.allTypeArome=x;
   } ,
   err => console.error('Observer got an error: ' + err),
   () => console.log('Observer got a complete notification')
 );
}

getStabilisant() : void {
  console.log('get stabilisant ');
  this.http.get<Ingredient>((`${this.apiServerUrl}/api/ingredient/stabilisant`)).
  subscribe(
   x => {
     console.log('Observer got a next value: ' + x);
     this.stabilisant=x;
   } ,
   err => console.error('Observer got an error: ' + err),
   () => console.log('Observer got a complete notification')
 );
}

 loadAllArome1() : void {

switch (this.selectedTypeArome1) {
  case "FRUIT100":
      this.allArome1 = this.allFruit100;
    break;

  case "FRUIT_SUCRE":
      this.allArome1 = this.allFruitSucre;
    break;

    case "AUTRE_AROME":
      this.allArome1 = this.allAutreArome;
    break;

    case "CHOCOLAT":
      this.allArome1 = this.allChocolat;
    break;
    
  default:
    console.log("default switch selected type AROME");
 }
 }

 loadAllArome2() : void {

  switch (this.selectedTypeArome2) {
    case "FRUIT100":
        this.allArome2 = this.allFruit100;
      break;
  
    case "FRUIT_SUCRE":
        this.allArome2 = this.allFruitSucre;
      break;
  
      case "AUTRE_AROME":
        this.allArome2 = this.allAutreArome;
      break;
  
      case "CHOCOLAT":
        this.allArome2 = this.allChocolat;
      break;
      
    default:
      console.log("default switch selected type AROME");
   }
   }

   loadAllArome3() : void {

    switch (this.selectedTypeArome3) {
      case "FRUIT100":
          this.allArome3 = this.allFruit100;
        break;
    
      case "FRUIT_SUCRE":
          this.allArome3 = this.allFruitSucre;
        break;
    
        case "AUTRE_AROME":
          this.allArome3 = this.allAutreArome;
        break;
    
        case "CHOCOLAT":
          this.allArome3 = this.allChocolat;
        break;
        
      default:
        console.log("default switch selected type AROME");
     }
     }

     loadAllArome4() : void {

      switch (this.selectedTypeArome4) {
        case "FRUIT100":
            this.allArome4 = this.allFruit100;
          break;
      
        case "FRUIT_SUCRE":
            this.allArome4 = this.allFruitSucre;
          break;
      
          case "AUTRE_AROME":
            this.allArome4 = this.allAutreArome;
          break;
      
          case "CHOCOLAT":
            this.allArome4 = this.allChocolat;
          break;
          
        default:
          console.log("default switch selected type AROME");
       }
       }

 selectTypeArome1(evt: any) {
  this.selectedTypeArome1 = evt.target.value;
}

selectTypeArome2(evt: any) {
  this.selectedTypeArome2 = evt.target.value;
}

selectTypeArome3(evt: any) {

  this.selectedTypeArome3 = evt.target.value;
}

selectTypeArome4(evt: any) {
  this.selectedTypeArome4 = evt.target.value;
}

selectArome1(){
  this.http.get<Ingredient>((`${this.apiServerUrl}/api/ingredient/`+ this.nomArome1)).
   subscribe(
    x => {
      console.log('Observer got a next value: ' + x);
      this.arome1=x;
    } ,
    err => console.error('Observer got an error: ' + err),
    () => console.log('Observer got a complete notification')
  );
}

selectArome2(){
  this.http.get<Ingredient>((`${this.apiServerUrl}/api/ingredient/`+ this.nomArome2)).
   subscribe(
    x => {
      console.log('Observer got a next value: ' + x);
      this.arome2=x;
    } ,
    err => console.error('Observer got an error: ' + err),
    () => console.log('Observer got a complete notification')
  );
}

selectArome3(){
  this.http.get<Ingredient>((`${this.apiServerUrl}/api/ingredient/`+ this.nomArome3)).
   subscribe(
    x => {
      console.log('Observer got a next value: ' + x);
      this.arome3=x;
    } ,
    err => console.error('Observer got an error: ' + err),
    () => console.log('Observer got a complete notification')
  );
}

selectArome4(){
  this.http.get<Ingredient>((`${this.apiServerUrl}/api/ingredient/`+ this.nomArome4)).
   subscribe(
    x => {
      console.log('Observer got a next value: ' + x);
      this.arome4=x;
    } ,
    err => console.error('Observer got an error: ' + err),
    () => console.log('Observer got a complete notification')
  );
}

calculer(){
  this.prixTotal=0;
  this.pouvoirSucrantTotal=0;
  this.extraitSecTotal=0;
  this.poidsSucreArometotal=0;
  this.sucreAjoute = 0;
  this.tauxFruit = 0;
  var poidsSorbetSansEau=0;
  var poidsSerum=0;
  var poidsOeuf=0;
 
  var poidsESDLMIX=0;
  this.poidsPoudreLait=0;
  var poidsGrasMIX = 0;

  var poidsGrasContenuDanschocolat=0;
  var poidsGrasContenuDansOeuf=0;
  var poidsGrasContenuDansMG2=0;
  var poidsGrasAjoute = 0;
  var poidsESDLajoute = 0;

  var tauxMGgras1 = 0;
  var tauxMGgras2 = 0;
  var tauxESDLgras2 = 0;
  var tauxESTgras1 = 0;
  var tauxESTgras2 = 0;
  var prixMG1auGramme=0;
  var prixMG2auGramme=0;
  var psMG1 = 0;
  var psMG2 = 0;

  var poidsArome1=0;
  var poidsArome2=0;
  var poidsArome3=0;
  var poidsArome4=0;

  var poidsSucreArome1=0;
  var poidsSucreArome2=0;
  var poidsSucreArome3=0;
  var poidsSucreArome4=0;
  var poidsStabilisant=0;

  var poidsSaccharose = 0;
  var poidsGlucose = 0;
  var poidsSucreInverti = 0;
  var poidsDextrose = 0;

  poidsArome1 = this.pourCentArome1*this.poidsTotalMIX/100;
  poidsArome2 = this.pourCentArome2*this.poidsTotalMIX/100;
  poidsArome3 = this.pourCentArome3*this.poidsTotalMIX/100;
  poidsArome4 = this.pourCentArome4*this.poidsTotalMIX/100;

  var pouvoirSucrantArome1 =0;
  var pouvoirSucrantArome2 =0;
  var pouvoirSucrantArome3 =0;
  var pouvoirSucrantArome4 =0;

  var poidsSucre = 0;
  var poidsPoudreLaitSorbet = 0;
  

  switch (this.selectedTypeGras1) {
    case "BEURRE82":
      tauxMGgras1=820;
      tauxESTgras1=0.84;
      prixMG1auGramme=0.008;
      psMG1=0.02;
      break;
  
    case "CREME35":
      tauxMGgras1=350;
      tauxESTgras1=0.41;
      prixMG1auGramme=0.003;
      psMG1=0.06;
      break;
  
    case "CREME40":
      tauxMGgras1=400;
      tauxESTgras1=0.455;
      prixMG1auGramme=0.003;
      psMG1=0.055;
      break;
      
    default:
      console.log("default switch selected type GRAS-1");
   }
  
   switch (this.selectedTypeGras2) {
    case "BEURRE82":
      tauxMGgras2=820;
      tauxESDLgras2=2;
      tauxESTgras2=0.84;
      prixMG2auGramme=0.008;
      psMG2=0.02;
      break;
  
    case "CREME35":
      tauxMGgras2=350;
      tauxESDLgras2=6;
      tauxESTgras2=0.41;
      prixMG2auGramme=0.003;
      psMG2=0.06;
      break;
  
    case "CREME40":
      tauxMGgras2=400;
      tauxESDLgras2=5.5;
      tauxESTgras2=0.455;
      prixMG2auGramme=0.003;
      psMG2=0.055;
      break;
      
    default:
      console.log("default switch selected type GRAS-2");
   }
 
  //MG Total et Oeufs
   poidsOeuf=this.poidsTotalMIX*this.jauneDoeufPourCent/100;
   poidsGrasMIX=this.poidsTotalMIX*this.grasTotalPourCent/100;

   //ESDL TOTAL
   poidsESDLMIX=this.poidsTotalMIX*this.esdlTotalPourCent/100;

  //SUCRE TOTAL
  poidsSucre = this.sucreTotalPourCent * this.poidsTotalMIX /100; 

  //stabilisant
  this.extraitSecTotal += this.stabilisantPourCent;
  poidsStabilisant = this.stabilisantPourCent * this.poidsTotalMIX /100;

  //AROMES   
  if(this.arome1.id != null){
    poidsSucreArome1=poidsArome1*this.arome1.taux_sucre;
    this.poidsSucreArometotal+=poidsSucreArome1;
    if(this.arome1.type === "AUTRE_AROME" || this.arome1.type === "CHOCOLAT"){
      pouvoirSucrantArome1 = poidsSucreArome1*100/this.poidsTotalMIX;
      this.pouvoirSucrantTotal+=pouvoirSucrantArome1;
      poidsGrasAjoute+=this.arome1.gras*poidsArome1;
      this.extraitSecTotal+=this.arome1.extrait_sec*poidsArome1/this.poidsTotalMIX;
    }else{
      if(this.arome1.type === "FRUIT_SUCRE"){
        var extraitSecFruit=0;
        var extraitSecSucreInvertiArome1=0;
        var poidsSucreInvertiArome1=(1-this.arome1.taux_fruit)*poidsArome1;
        var poidsFruit=this.arome1.taux_fruit*poidsArome1;
        var pouvoirSucrantFruit=0;
        var pouvoirSucrantSucreInvertiArome1=0;
        extraitSecFruit=(this.arome1.extrait_sec*poidsFruit)/this.poidsTotalMIX;
        extraitSecSucreInvertiArome1=this.sucreInverti.extrait_sec*poidsSucreInvertiArome1/this.poidsTotalMIX;
        this.extraitSecTotal+=extraitSecFruit+extraitSecSucreInvertiArome1;
        pouvoirSucrantFruit=this.arome1.coefficient_pouvoir_sucrant*extraitSecFruit;
        pouvoirSucrantSucreInvertiArome1=this.sucreInverti.coefficient_pouvoir_sucrant*poidsSucreInvertiArome1/this.poidsTotalMIX*100;
        this.pouvoirSucrantTotal+=pouvoirSucrantFruit+pouvoirSucrantSucreInvertiArome1;
      }
      if(this.arome1.type === "FRUIT100"){
        this.extraitSecTotal+=this.arome1.extrait_sec*poidsArome1/this.poidsTotalMIX;
        this.pouvoirSucrantTotal+=this.arome1.coefficient_pouvoir_sucrant
        *this.arome1.extrait_sec*poidsArome1/this.poidsTotalMIX;
      }
      
    }
    
    this.prixTotal+=poidsArome1*this.arome1.prix_au_gramme;
    this.tauxFruit+=poidsArome1*this.arome1.taux_fruit/this.poidsTotalMIX;
  } 
  if(this.arome2.id != null){
    poidsSucreArome2=poidsArome2*this.arome2.taux_sucre;
    this.poidsSucreArometotal+=poidsSucreArome2;
    if(this.arome2.type === "AUTRE_AROME" || this.arome2.type === "CHOCOLAT"){
      pouvoirSucrantArome2 = poidsSucreArome2*100/this.poidsTotalMIX;
      this.pouvoirSucrantTotal+=pouvoirSucrantArome2;
      poidsGrasAjoute+=this.arome2.gras*poidsArome2;
      this.extraitSecTotal+=this.arome2.extrait_sec*poidsArome2/this.poidsTotalMIX;
    }else{
      if(this.arome2.type === "FRUIT_SUCRE"){
        var extraitSecFruit=0;
        var extraitSecSucreInvertiArome2=0;
        var poidsSucreInvertiArome2=(1-this.arome2.taux_fruit)*poidsArome2;
        var poidsFruit=this.arome2.taux_fruit*poidsArome2;
        var pouvoirSucrantFruit=0;
        var pouvoirSucrantSucreInvertiArome2=0;
        extraitSecFruit=(this.arome2.extrait_sec*poidsFruit)/this.poidsTotalMIX;
        extraitSecSucreInvertiArome2=this.sucreInverti.extrait_sec*poidsSucreInvertiArome2/this.poidsTotalMIX;
        this.extraitSecTotal+=extraitSecFruit+extraitSecSucreInvertiArome2;
        pouvoirSucrantFruit=this.arome2.coefficient_pouvoir_sucrant*extraitSecFruit;
        pouvoirSucrantSucreInvertiArome2=this.sucreInverti.coefficient_pouvoir_sucrant*poidsSucreInvertiArome2/this.poidsTotalMIX*100;
        this.pouvoirSucrantTotal+=pouvoirSucrantFruit+pouvoirSucrantSucreInvertiArome2;
      }
      if(this.arome2.type === "FRUIT100"){
        this.extraitSecTotal+=this.arome2.extrait_sec*poidsArome2/this.poidsTotalMIX;
        this.pouvoirSucrantTotal+=this.arome2.coefficient_pouvoir_sucrant
        *this.arome2.extrait_sec*poidsArome2/this.poidsTotalMIX;
      }
      
    }
    
    this.prixTotal+=poidsArome2*this.arome2.prix_au_gramme;
    this.tauxFruit+=poidsArome2*this.arome2.taux_fruit/this.poidsTotalMIX;
  } 
  if(this.arome3.id != null){
    poidsSucreArome3=poidsArome3*this.arome3.taux_sucre;
    this.poidsSucreArometotal+=poidsSucreArome3;
    if(this.arome3.type === "AUTRE_AROME" || this.arome3.type === "CHOCOLAT"){
      pouvoirSucrantArome3 = poidsSucreArome3*100/this.poidsTotalMIX;
      this.pouvoirSucrantTotal+=pouvoirSucrantArome3;
      poidsGrasAjoute+=this.arome3.gras*poidsArome3;
      this.extraitSecTotal+=this.arome3.extrait_sec*poidsArome3/this.poidsTotalMIX;
    }else{
      if(this.arome3.type === "FRUIT_SUCRE"){
        var extraitSecFruit=0;
        var extraitSecSucreInvertiArome3=0;
        var poidsSucreInvertiArome3=(1-this.arome3.taux_fruit)*poidsArome3;
        var poidsFruit=this.arome3.taux_fruit*poidsArome3;
        var pouvoirSucrantFruit=0;
        var pouvoirSucrantSucreInvertiArome3=0;
        extraitSecFruit=(this.arome3.extrait_sec*poidsFruit)/this.poidsTotalMIX;
        extraitSecSucreInvertiArome3=this.sucreInverti.extrait_sec*poidsSucreInvertiArome3/this.poidsTotalMIX;
        this.extraitSecTotal+=extraitSecFruit+extraitSecSucreInvertiArome3;
        pouvoirSucrantFruit=this.arome3.coefficient_pouvoir_sucrant*extraitSecFruit;
        pouvoirSucrantSucreInvertiArome3=this.sucreInverti.coefficient_pouvoir_sucrant*poidsSucreInvertiArome3/this.poidsTotalMIX*100;
        this.pouvoirSucrantTotal+=pouvoirSucrantFruit+pouvoirSucrantSucreInvertiArome3;
      }
      if(this.arome3.type === "FRUIT100"){
        this.extraitSecTotal+=this.arome3.extrait_sec*poidsArome3/this.poidsTotalMIX;
        this.pouvoirSucrantTotal+=this.arome3.coefficient_pouvoir_sucrant
        *this.arome3.extrait_sec*poidsArome3/this.poidsTotalMIX;
      }
      
    }
    
    this.prixTotal+=poidsArome3*this.arome3.prix_au_gramme;
    this.tauxFruit+=poidsArome3*this.arome3.taux_fruit/this.poidsTotalMIX;
  } 
  if(this.arome4.id != null){
    poidsSucreArome4=poidsArome4*this.arome4.taux_sucre;
    this.poidsSucreArometotal+=poidsSucreArome4;
    if(this.arome4.type === "AUTRE_AROME" || this.arome4.type === "CHOCOLAT"){
      pouvoirSucrantArome4 = poidsSucreArome4*100/this.poidsTotalMIX;
      this.pouvoirSucrantTotal+=pouvoirSucrantArome4;
      poidsGrasAjoute+=this.arome4.gras*poidsArome4;
      this.extraitSecTotal+=this.arome4.extrait_sec*poidsArome4/this.poidsTotalMIX;
    }else{
      if(this.arome4.type === "FRUIT_SUCRE"){
        var extraitSecFruit=0;
        var extraitSecSucreInvertiArome4=0;
        var poidsSucreInvertiArome4=(1-this.arome4.taux_fruit)*poidsArome4;
        var poidsFruit=this.arome4.taux_fruit*poidsArome4;
        var pouvoirSucrantFruit=0;
        var pouvoirSucrantSucreInvertiArome4=0;
        extraitSecFruit=(this.arome4.extrait_sec*poidsFruit)/this.poidsTotalMIX;
        extraitSecSucreInvertiArome4=this.sucreInverti.extrait_sec*poidsSucreInvertiArome4/this.poidsTotalMIX;
        this.extraitSecTotal+=extraitSecFruit+extraitSecSucreInvertiArome4;
        pouvoirSucrantFruit=this.arome4.coefficient_pouvoir_sucrant*extraitSecFruit;
        pouvoirSucrantSucreInvertiArome4=this.sucreInverti.coefficient_pouvoir_sucrant*poidsSucreInvertiArome4/this.poidsTotalMIX*100;
        this.pouvoirSucrantTotal+=pouvoirSucrantFruit+pouvoirSucrantSucreInvertiArome4;
      }
      if(this.arome4.type === "FRUIT100"){
        this.extraitSecTotal+=this.arome4.extrait_sec*poidsArome4/this.poidsTotalMIX;
        this.pouvoirSucrantTotal+=this.arome4.coefficient_pouvoir_sucrant
        *this.arome4.extrait_sec*poidsArome4/this.poidsTotalMIX;
      }
      
    }
    
    this.prixTotal+=poidsArome4*this.arome4.prix_au_gramme;
    this.tauxFruit+=poidsArome4*this.arome4.taux_fruit/this.poidsTotalMIX;
  } 
  
  //Sucre ajouté
  this.sucreAjoute = poidsSucre - this.poidsSucreArometotal;
  
  //SUCRES
  poidsSaccharose=this.saccharosePourCent*this.sucreAjoute/100;
  poidsGlucose= this.glucosePourCent*this.sucreAjoute/100;
  poidsSucreInverti=this.sucreInvertiPourCent*this.sucreAjoute/100;
  poidsDextrose+=this.dextrosePourCent*this.sucreAjoute/100;

  if(this.saccharose.extrait_sec != null){
    this.extraitSecTotal+=this.saccharose.extrait_sec*poidsSaccharose/this.poidsTotalMIX;
    this.pouvoirSucrantTotal+=this.saccharose.coefficient_pouvoir_sucrant*poidsSaccharose/this.poidsTotalMIX*100;
    this.prixTotal+=this.saccharose.prix_au_gramme*poidsSaccharose;
  }
  if(this.glucose.extrait_sec != null){
    this.extraitSecTotal+=this.glucose.extrait_sec*poidsGlucose/this.poidsTotalMIX;
    this.pouvoirSucrantTotal+=this.glucose.coefficient_pouvoir_sucrant*poidsGlucose/this.poidsTotalMIX*100;
    this.prixTotal+=this.glucose.prix_au_gramme*poidsGlucose;
  }
  if(this.sucreInverti.extrait_sec != null){
    this.extraitSecTotal+=this.sucreInverti.extrait_sec*poidsSucreInverti/this.poidsTotalMIX;
    this.pouvoirSucrantTotal+=this.sucreInverti.coefficient_pouvoir_sucrant*poidsSucreInverti/this.poidsTotalMIX*100;
    this.prixTotal+=this.sucreInverti.prix_au_gramme*poidsSucreInverti;
  }
  if(this.dextrose.extrait_sec != null){
    this.extraitSecTotal+=this.dextrose.extrait_sec*poidsDextrose/this.poidsTotalMIX;
    this.pouvoirSucrantTotal+=this.dextrose.coefficient_pouvoir_sucrant*poidsDextrose/this.poidsTotalMIX*100;
    this.prixTotal+=this.dextrose.prix_au_gramme*poidsDextrose;
  }



  //RESULTATS

  //poids_ESDL_produit_laitier=poidsPL*taux_esdl
  //ps_produit_laitier=(poids_ESDL_produit_laitier/2)*0.16

  if(this.selectedTypeGlace === "SORBET"){
    poidsPoudreLaitSorbet=this.poudreLaitSorbetPourcent/100*this.poidsTotalMIX
    this.extraitSecTotal+=this.poudreLaitSorbetPourcent*0.97;
   this.pouvoirSucrantTotal+=((poidsPoudreLaitSorbet*0.96)/2)*0.16*100/this.poidsTotalMIX;
  }
  
  //poids total sans eau pour sorbet
  poidsSorbetSansEau=this.sucreAjoute+poidsArome1+poidsArome2+poidsArome3+poidsArome4+poidsStabilisant+poidsPoudreLaitSorbet;

  if(this.selectedTypeGlace === "CREME_GLACE" || this.selectedTypeGlace === "CREME_OEUF"){
  //oeuf
  poidsGrasAjoute+=poidsOeuf*0.30;
  this.extraitSecTotal+=poidsOeuf*0.5*100/this.poidsTotalMIX;
  this.prixTotal+=poidsOeuf*0.0065;

  poidsGrasAjoute+=this.poidsGras2*tauxMGgras2/1000;
  poidsESDLajoute+=this.poidsGras2*(tauxESDLgras2/100);
  this.pouvoirSucrantTotal+=((this.poidsGras2*0.06)/2)*0.16*100/this.poidsTotalMIX;

  poidsESDLMIX -= poidsESDLajoute; 
  poidsGrasMIX -= poidsGrasAjoute;

  poidsSerum=this.poidsTotalMIX-(poidsSorbetSansEau+poidsGrasMIX+poidsOeuf+this.poidsGras2);
  
  this.poidsPoudreLait=((poidsESDLMIX/1000-(poidsSerum/1000*88/1000))/(970/1000-88/1000))*1000;
  this.extraitSecTotal+=this.poidsPoudreLait*0.97*100/this.poidsTotalMIX;
  this.prixTotal+=this.poidsPoudreLait*0.007;
  this.pouvoirSucrantTotal+=((this.poidsPoudreLait*0.96)/2)*0.16*100/this.poidsTotalMIX;
  
  poidsSerum=this.poidsTotalMIX-(poidsSorbetSansEau+this.poidsPoudreLait+poidsOeuf+this.poidsGras2);
  this.pouvoirSucrantTotal+=((this.poidsGras1*0.06)/2)*0.16*100/this.poidsTotalMIX;
  this.poidsGras1=((poidsGrasMIX/1000-(poidsSerum/1000*36/1000))/(tauxMGgras1/1000-36/1000))*1000;
  this.extraitSecTotal+=this.poidsGras1*tauxESTgras1*100/this.poidsTotalMIX;
  this.extraitSecTotal+=this.poidsGras2*tauxESTgras2*100/this.poidsTotalMIX;
  this.prixTotal+=prixMG1auGramme*this.poidsGras1;
  this.prixTotal+=prixMG2auGramme*this.poidsGras2;
  this.poidsLaitEntier=this.poidsTotalMIX
                      -(poidsSorbetSansEau+this.poidsPoudreLait+this.poidsGras1
                        + this.poidsGras2 + poidsOeuf);
  this.extraitSecTotal+= this.poidsLaitEntier*0.12*100/this.poidsTotalMIX;  
  this.pouvoirSucrantTotal+=((this.poidsLaitEntier*0.084)/2)*0.16*100/this.poidsTotalMIX;
  this.prixTotal+=this.poidsLaitEntier*0.001;
  }

  this.poidsEau=this.poidsTotalMIX-poidsSorbetSansEau;
  this.prixTotal=this.prixTotal*1000/this.poidsTotalMIX;
  this.tauxFruit=this.tauxFruit*100;
  

}

ajouterMatiereGrasse(){
    this.ajouterMG=true;
}

}
