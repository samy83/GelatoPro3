import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SorbetComponent } from './sorbet.component';

describe('SorbetComponent', () => {
  let component: SorbetComponent;
  let fixture: ComponentFixture<SorbetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SorbetComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SorbetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
