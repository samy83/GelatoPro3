export class Ingredient{

    id !: number;

    nom !: string;

    type !: string;

    taux_sucre !: number;

    extrait_sec !: number;

    prix_au_gramme !: number;

    fournisseur !: string;

    gras !: number;

    coefficient_pouvoir_sucrant !: number;

    taux_fruit !: number;
    
}