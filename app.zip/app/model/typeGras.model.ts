export class TypeGras {
    libelle : string="";
    valeurEnum : string="";
}