export class TypeGlace {
    libelle : string="";
    valeurEnum : string="";
}