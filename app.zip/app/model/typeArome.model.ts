export class TypeArome {
    libelle : string="";
    valeurEnum : string="";
}