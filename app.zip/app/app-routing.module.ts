import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SorbetComponent } from './sorbet/sorbet.component';
import { AjoutIngredientComponent } from './ajout-ingredient/ajout-ingredient.component';

const routes: Routes = [
  { path: 'recette', component: SorbetComponent },
  { path: 'ingredient', component: AjoutIngredientComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {


  
 }
