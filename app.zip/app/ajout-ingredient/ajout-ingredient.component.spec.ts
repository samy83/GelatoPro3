import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AjoutIngredientComponent } from './ajout-ingredient.component';

describe('AjoutIngredientComponent', () => {
  let component: AjoutIngredientComponent;
  let fixture: ComponentFixture<AjoutIngredientComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AjoutIngredientComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AjoutIngredientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
