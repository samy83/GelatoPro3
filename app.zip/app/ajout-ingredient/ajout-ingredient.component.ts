import { Component } from '@angular/core';
import { Injectable } from '@angular/core';
import {TypeArome} from '../model/typeArome.model'
import { HttpClient } from '@angular/common/http';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-ajout-ingredient',
  templateUrl: './ajout-ingredient.component.html',
  styleUrls: ['./ajout-ingredient.component.scss']
})

@Injectable()
export class AjoutIngredientComponent {

  ngAfterContentInit()
   {

    this.getAllTypeArome();

  }
  
  constructor(private http: HttpClient) { }

  ajouterAromeForm : FormGroup = new FormGroup({

  nom    : new FormControl('', Validators.required ),

  type   : new FormControl('', Validators.required),

  fournisseur    : new FormControl('', Validators.required),

  tauxGras        : new FormControl(null, [Validators.min(0), Validators.max(100)]),

  tauxSucre     : new FormControl(null, [Validators.min(0), Validators.max(100)]),

  tauxFruit      : new FormControl(null, [Validators.min(0), Validators.max(100)]),

  extraitSec  : new FormControl(null, Validators.required),

  prixKG        : new FormControl(null, Validators.min(0))

});

  apiServerUrl='http://localhost:8080'

  allTypeArome: TypeArome[] = [];

  getAllTypeArome() : void {
    this.http.get<TypeArome[]>((`${this.apiServerUrl}/api/ingredient/type-arome/all`)).
    subscribe(
     x => {
       console.log('Observer got a next value: ' + x);
       x.forEach(element => {
         console.log(element.libelle);
       });
       this.allTypeArome=x;
     } ,
     err => console.error('Observer got an error: ' + err),
     () => console.log('Observer got a complete notification')
   );
  }

  saveArome(){
    if (this.ajouterAromeForm.valid)
    {
      var formData: FormData = new FormData();
      formData.append('nom', this.ajouterAromeForm.get('nom')?.value);
      formData.append('type', this.ajouterAromeForm.get('type')?.value);
      formData.append('fournisseur', this.ajouterAromeForm.get('fournisseur')?.value);
      formData.append('tauxGras', this.ajouterAromeForm.get('tauxGras')?.value);
      formData.append('tauxSucre', this.ajouterAromeForm.get('tauxSucre')?.value);
      formData.append('tauxFruit', this.ajouterAromeForm.get('tauxFruit')?.value);
      formData.append('extraitSec', this.ajouterAromeForm.get('extraitSec')?.value);
      formData.append('prixKG', this.ajouterAromeForm.get('prixKG')?.value);

      this.http
        .post(`${this.apiServerUrl}/api/ingredient/ingredient`, formData)
        .subscribe({
          next: (response : any) =>{
            console.log(response);
            console.log("nouvel arome !!!");
          } ,
          error: (error) =>{
            console.log(error);
          } ,
        });
    }
    else
    {
      this.ajouterAromeForm.markAllAsTouched();
    }
  }

}
